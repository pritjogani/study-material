// var a = ["prit"];
// a.push("prit");
// console.log(a);


// var arr1 = [5,2,3,5,8];
// var arr2 = arr1.map(((element) => element * 2)).filter((element) => element>10)
// console.log(arr2);
// console.log(arr1);


// var arr1 = [5,2,3,5,8];
// arr1 = arr1.forEach((element) => element*2)
// console.log(arr1);





