var arr1 = [5,2,3,5,8];
var arr2 = arr1.map(((element) => element * 2)).filter((element) => element>2)
console.log(arr2);
console.log(arr1);
